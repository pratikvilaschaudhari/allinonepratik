Lazera AllInOne App - Folder structure is ready.
To build the .exe:
1. Install Python (https://www.python.org/downloads/)
2. Open Command Prompt inside this folder
3. Run: pip install pyinstaller
4. Then run: pyinstaller --onefile main.py
5. Find the .exe in the /dist/ folder created after build.
