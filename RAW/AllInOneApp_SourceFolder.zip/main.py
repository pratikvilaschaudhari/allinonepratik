# Main entry script
print('AllInOne App Loaded')
