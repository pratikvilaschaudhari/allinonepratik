This folder contains backend Python scripts and error log.
Do not delete. Run main.py after configuring to build the exe.